from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse
import math

# Create your models here.

class Section(models.Model):
    name = models.CharField(max_length=80)
    description = models.CharField(max_length=150)
    logo = models.ImageField()

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("visualize_section", kwargs={"pk": self.pk})
    
    def get_last_discussions(self):
        return Discussion.objects.filter(section=self).order_by("-creation_date")[:2]
    
    def get_number_of_posts(self):
        return Post.objects.filter(discussion__section=self).count()

    class Meta:
        verbose_name = "Section"
        verbose_name_plural = "Sections"

class Discussion(models.Model):
    title = models.CharField(max_length=120)
    creation_date = models.DateTimeField(auto_now_add=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name="discussions")
    section = models.ForeignKey(Section, on_delete=models.CASCADE)

    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse("visualize_discussion", kwargs={"pk": self.pk})
    
    def get_n_pages(self):
        posts_discussion = self.post_set.count()
        n_pages = math.ceil(posts_discussion / 5)
        return n_pages

    class Meta:
        verbose_name = "Discussion"
        verbose_name_plural = "Discussions"

class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name="posts")
    content = models.TextField()
    creation_date = models.DateTimeField(auto_now_add=True)
    discussion = models.ForeignKey(Discussion, on_delete=models.CASCADE)

    def __str__(self):
        return self.author.username

    class Meta:
        verbose_name = "Post"
        verbose_name_plural = "Posts"