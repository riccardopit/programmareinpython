from django.urls import path

from . import views

urlpatterns = [
    path('new-section/', views.CreateSection.as_view(), name="create_section"),
    path('section/<int:pk>/', views.visualize_section, name="visualize_section"),
    path('section/<int:pk>/create-discussion/', views.create_discussion, name="create_discussion"),
    path('discussion/<int:pk>/', views.visualize_discussion, name="visualize_discussion"),
    path('discussion/<int:pk>/answer/', views.add_answer, name="add_answer"),
    path('discussion/<int:id>/delete-post/<int:pk>/', views.DeletePost.as_view(), name="delete_post")
]