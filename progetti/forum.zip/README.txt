### REQUIREMENTS ###

django 5.0.1
django-crispy-forms 2.1
crispy-bootstrap5 2023.10
pillow 10.2.0

### USERS ###

Username: admin
Email: admin@admin.it
Password: adminsocialsite

Username: riccardopit
Email: riccardopit@django.com
Password: socialsite