from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import HttpResponseRedirect, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views.generic.edit import CreateView, DeleteView

from .forms import DiscussionModelForm, PostModelForm
from .mixins import StaffMixin
from .models import Discussion, Post, Section

# Create your views here.

class CreateSection(StaffMixin, CreateView):
    model = Section
    fields = "__all__"
    template_name = "forum/create_section.html"
    success_url = "/"

def visualize_section(request, pk):
    section = get_object_or_404(Section, pk=pk)
    discussions_section = Discussion.objects.filter(section=section).order_by("-creation_date")
    context = {"section": section, "discussions_section": discussions_section}
    return render(request, "forum/single_section.html", context)

@login_required
def create_discussion(request, pk):
    section = get_object_or_404(Section, pk=pk)
    if request.method == "POST":
        form = DiscussionModelForm(request.POST)
        if form.is_valid():
            discussion = form.save(commit=False)
            discussion.section = section
            discussion.author = request.user
            discussion.save()
            first_post = Post.objects.create(discussion=discussion, author=request.user, content=form.cleaned_data["content"])
            return HttpResponseRedirect(discussion.get_absolute_url())
    else:
        form = DiscussionModelForm()
    context = {"form": form, "section": section}
    return render(request, "forum/create_discussion.html", context)

def visualize_discussion(request, pk):
    discussion = get_object_or_404(Discussion, pk=pk)
    posts_discussion = Post.objects.filter(discussion=discussion)
    paginator = Paginator(posts_discussion, 5)
    page = request.GET.get("page")
    posts = paginator.get_page(page)
    form_answer = PostModelForm()
    context = {"discussion": discussion, "posts_discussion": posts, "form_answer": form_answer}
    return render(request, "forum/single_discussion.html", context)

@login_required
def add_answer(request, pk):
    discussion = get_object_or_404(Discussion, pk=pk)
    if request.method == "POST":
        form = PostModelForm(request.POST)
        if form.is_valid():
            form.save(commit=False)
            form.instance.discussion = discussion
            form.instance.author = request.user
            form.save()
            url_discussion = reverse("visualize_discussion", kwargs={"pk": pk})
            pages_discussions = discussion.get_n_pages()
            if pages_discussions > 1:
                success_url = url_discussion + "?page=" + str(pages_discussions)
                return HttpResponseRedirect(success_url)
            else:
                return HttpResponseRedirect(url_discussion)
    else:
        HttpResponseBadRequest()

class DeletePost(DeleteView):
    model = Post
    success_url = "/"

    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.filter(author_id=self.request.user.id)