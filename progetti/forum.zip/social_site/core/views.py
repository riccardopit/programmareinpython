from django.contrib.auth.models import User
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, render, redirect
from django.views.generic.list import ListView

from forum.models import Discussion, Section, Post

# Create your views here.

class HomeView(ListView):
    queryset = Section.objects.all()
    template_name = "core/homepage.html"
    context_object_name = "section_list"

class UserList(LoginRequiredMixin, ListView):
    model = User
    template_name = "core/users.html"
    context_object_name = "user_list"

def user_profile_view(request, username):
    user = get_object_or_404(User, username=username)
    user_discussions = Discussion.objects.filter(author=user).order_by("-pk")
    context = {"user": user, "user_discussions": user_discussions}
    return render(request, "core/user_profile.html", context)

def search(request):
    if "q" in request.GET:
        querystring = request.GET.get("q")
        if len(querystring) == 0:
            return redirect("search/")
        discussions = Discussion.objects.filter(title__icontains=querystring)
        posts = Post.objects.filter(content__icontains=querystring)
        users = User.objects.filter(username__icontains=querystring)
        context = {"discussions": discussions, "posts": posts, "users": users}
        return render(request, "core/search.html", context)
    else:
        return render(request, "core/search.html")