from django.contrib import admin

from .models import Discussion, Post, Section

# Register your models here.

class DiscussionModelAdmin(admin.ModelAdmin):
    model=Discussion
    list_display = ["title", "section", "author"]
    search_fields = ["title", "author"]
    list_filter = ["section", "creation_date"]

class PostModelAdmin(admin.ModelAdmin):
    model=Post
    list_display = ["author", "discussion"]
    search_fields = ["content"]
    list_filter = ["creation_date", "author"]

class SectionModelAdmin(admin.ModelAdmin):
    model=Section
    list_display = ["name", "description"]

admin.site.register(Section, SectionModelAdmin)
admin.site.register(Discussion, DiscussionModelAdmin)
admin.site.register(Post, PostModelAdmin)